import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'emp-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm: FormGroup;
  issuccess;
  constructor(private fb: FormBuilder, private router: Router) {
    this.loginForm = this.fb.group({
      username: [
        '',
        Validators.compose([Validators.required, Validators.minLength(6)])
      ],
      password: ['', Validators.required]
    });
  }

  onSubmit(): void {
    try {
      /*  console.log(this.loginForm.controls['username'].value);
      console.log(this.loginForm.controls['password'].value);
      console.log(this.loginForm.value); */
      const username = this.loginForm.controls['username'].value;
      const pwd = this.loginForm.controls['password'].value;
      if (username === 'srinivas' && pwd === '12345') {
        this.issuccess = true;
        alert('Welcome your login Success');
        this.router.navigate(['employee']);
      } else {
        this.issuccess = false;
        alert('Please login with correct credentials');
      }
    } catch (e) {
      console.log(' Error in Login Page ' + e.message);
    }
  }
}
