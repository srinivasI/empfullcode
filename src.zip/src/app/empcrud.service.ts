import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Emp } from './emp';

@Injectable({
  providedIn: 'root'
})
export class EmpcrudService {
  response: Emp;
  errormsg;
  constructor(private http: HttpClient) {}

  getEmpData() {
    return this.http.get('http://dummy.restapiexample.com/api/v1/employees');
  }
  deleteRecord() {
    return this.http.delete(
      'http://dummy.restapiexample.com/api/v1/update/22091'
    );
  }
  createRecord(data) {
    return this.http.post(
      'http://dummy.restapiexample.com/api/v1/create',
      JSON.stringify(data)
    );
  }

  private empList: Emp[] = [
    new Emp(1, 'Srinivasa Rao Ippili ', 50000, 30, '../../assets/srini.jpg'),
    new Emp(2, 'Jitendar', 90000, 33, '../../assets/srini.jpg'),
    new Emp(3, 'Balu', 30000, 35, '../../assets/srini.jpg'),
    new Emp(4, 'Singh', 60000, 33, '../../assets/srini.jpg'),
    new Emp(5, 'Siva', 20000, 32, '../../assets/srini.jpg'),
    new Emp(6, 'Swetha', 80000, 28, '../../assets/srini.jpg')
  ];

  getItems() {
    return this.empList;
  }

  addEmp(empRec: Emp) {
    this.empList.push(empRec);
  }
  editEmp(oldEmp: Emp, newEmp: Emp) {
    this.empList[this.empList.indexOf(oldEmp)] = newEmp;
  }
  deleteEmp(item: Emp) {
    this.empList.splice(this.empList.indexOf(item), 1);
  }
  getLength() {
    return this.empList.length;
  }
}
