import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges
} from '@angular/core';
import { Emp } from '../emp';
import { EmpcrudService } from '../empcrud.service';

@Component({
  selector: 'app-employeecrud',
  templateUrl: './employeecrud.component.html',
  styleUrls: ['./employeecrud.component.scss']
})
export class EmployeecrudComponent implements OnInit, OnChanges {
  @Input() empdata: Emp;
  @Output() cleared = new EventEmitter();
  isAdd = true;
  constructor(private empcs: EmpcrudService) {}

  ngOnInit() {}
  ngOnChanges(changes) {
    if (changes.empdata.currentValue == null) {
      this.isAdd = true;
      this.empdata = {
        employee_name: null,
        employee_salary: null,
        employee_age: null
      };
    } else {
      this.isAdd = false;
    }
  }
  onSubmit(newempdata: Emp) {
    const arrlen = this.empcs.getLength()+1;

    if (!this.isAdd) {
      const newEmpData1 = new Emp(
        this.empdata.id,
        newempdata.employee_name,
        newempdata.employee_salary,
        newempdata.employee_age,
        '../../assets/srini.jpg'
      );
      this.empcs.editEmp(this.empdata, newEmpData1);
    } else {
      const newEmpData = new Emp(
        arrlen,
        newempdata.employee_name,
        newempdata.employee_salary,
        newempdata.employee_age,
        '../../assets/srini.jpg'
      );
      this.empdata = newEmpData;
      this.empcs.addEmp(this.empdata);
    }
  }
  onDelete() {
    this.empcs.deleteEmp(this.empdata);
    this.onClear();
  }
  onClear() {
    this.cleared.emit(null);
  }
}
