import { Component, OnInit, ɵConsole } from '@angular/core';
import { EmpcrudService } from '../empcrud.service';
import { HttpClient } from '@angular/common/http';
import { Emp } from '../emp';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss']
})
export class EmployeeComponent implements OnInit {
  employdata;
  errormsg;
  success;
  constructor(
    private empcrud: EmpcrudService,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit() {
    try {
      // getting all employee data
      /*  this.empcrud.getEmpData()
         .subscribe(res => this.employdata = <Emp>res, error => this.errormsg = 'no emp data found'); */
      this.employdata = this.empcrud.getItems();
    } catch (e) {
      console.log('emp component init error ' + e.message);
    }
  }
  /*   deleteEmp(id) {
      try {
        // Delete seleted employee record
        this.empcrud.deleteRecord()
          .subscribe(res => this.success = <Emp>res, error => this.errormsg = 'Record not yet deleted');
      } catch (e) {
        console.log('emp component delete error ' + e.message);
      }
    } */

  
  selecitem: Emp;

  onselectItem(item) {
    this.selecitem = item;
  }
  onclear() {
    this.selecitem = null;
  }
}
